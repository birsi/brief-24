# Der Brief vom 24. Dezember

Web App zum Adventkalender-Rätsel 2026. Vite, React, TypeScript, kein Backend. Deploy auf Vercel.

## Schnellstart

```bash
npm install
npm run dev          # http://localhost:5173
npm test             # prüft, dass alle 24 Antworten ihre Tage öffnen
npm run build        # Produktions-Build nach dist/
```

Testmodus lokal: `http://localhost:5173/?dev=dev`, danach `/dev`.

## Deploy auf Vercel

1. Repo in Vercel importieren (Framework: Vite, Einstellungen kommen aus `vercel.json`).
2. Unter **Settings → Environment Variables** `DEV_SECRET` setzen, z. B. ein langes Zufallswort. Ohne diese Variable ist das Geheimnis `dev`.
3. Deployen. Testmodus: `https://<deine-domain>/?dev=<DEV_SECRET>`, dann `/dev`.

Das Repo sollte **privat** sein: `content/loesungen.json` enthält alle Lösungen.

## Wie Lösungen geschützt sind

- `content/loesungen.json` wird nur beim Build gelesen und nie ausgeliefert.
- Fortsetzung, Briefmarke und alles, was die Lösung verrät, werden pro Tag mit AES-GCM verschlüsselt. Der Schlüssel entsteht per PBKDF2 aus der normalisierten Antwort (Groß/klein, Umlaute, Leerzeichen egal). Im Bundle steht die Lösung nicht im Klartext.
- Hinweis 3 (= Lösung) ist nur leicht verschleiert.
- Der Testmodus hat einen eigenen Schlüssel aus `DEV_SECRET`.
- Fortschritt liegt im `localStorage` des Geräts. Wechselt Larissa das Gerät, im Testmodus die Tage nachträglich mit „Lösen“ setzen.

## Freischaltung

Tag N öffnet am N. Dezember 2026 um 0:00 Uhr Wiener Zeit (`GAME_YEAR` in `src/game/store.tsx`). Hinweise werden nach 3, 8 und 15 Minuten verfügbar (`HINT_MINUTES`). Im Testmodus sofort.

## Texte ändern

Die Texte kommen aus dem Claude-Doc „Der Brief vom 24. Dezember – Texte“.

1. Doc als Markdown exportieren und als `content/texte.md` speichern.
2. `npm run content` (läuft auch bei `dev`/`build` automatisch).

Übernommen werden pro Tag: Titel, Datumszeile, „App – Erzählung“ (nur reine Absätze, bis zum ersten fett markierten Label), „App – Fortsetzung“ (alle reinen Absätze) und die drei Hinweise. Fragen, Rätsel-Widgets und Spezialtexte stehen in `src/game/config.ts`, Antworten und Briefmarken in `content/loesungen.json`.

## Medien

Alles unter `public/media/`. Fehlt eine Datei, zeigt die App einen Platzhalter; fehlt ein Audio, liest die Browser-Stimme den Text vor. So lässt sich alles testen, bevor Bilder und ElevenLabs-Aufnahmen fertig sind.

```
public/media/tag-01/erzaehlung.jpg      Bild Erzählung (3:2, auch .webp oder .png)
public/media/tag-01/aufloesung.jpg      Bild Auflösung
public/media/tag-02/aufloesung.mp4      Video Auflösung (Tage 2, 12, 20, 22, 24), stumm, Schleife
public/media/tag-01/erzaehlung.mp3      Vorgelesene Erzählung
public/media/tag-01/fortsetzung.mp3     Vorgelesene Fortsetzung
```

Zusätzliche Audios:

| Datei | Inhalt |
|---|---|
| `tag-05/stimme-1.mp3` … `stimme-6.mp3` | Die sechs Alibis: Constanze, Hartl, Jonas, Frau Lenz, Mira, Bruno |
| `tag-16/satz-1.mp3` … `satz-4.mp3` | Jonas’ vier Sätze beim Heurigen |
| `tag-19/platte.mp3` | Die Grammophonplatte von 1926: „Trau nicht dem, der dir zuerst hilft.“ (mit Rauschen) |
| `tag-08/foto-1.jpg` … `foto-6.jpg` | Optional: Fotos im Album von Frau Lenz (Foto 4 = Mädchen mit Hund) |
| `kurrent-tabelle.png` | Kurrent-Alphabet für das Notizbuch (ab Tag 9) |

Erzeugt im Browser, ohne Datei: Glockenschläge (Tag 3), Morse-Ticken des Uhrwerks (Tag 22).

Die Bild-Prompts aller Tage stehen nach `npm run content` in `content/bild-prompts.txt`.

## QR-Codes für die Karten

```bash
npm run qr -- https://<deine-domain>
```

Erzeugt `qr/tag-01.svg` … `tag-24.svg` und PNGs (Gold #8A6A2F, transparenter Hintergrund) mit den Links `/tag/1` … `/tag/24`.

## Struktur

```
content/            Texte (Doc-Export), Lösungen, Bild-Prompts
scripts/            Inhalt bauen und verschlüsseln, QR-Codes, Antwort-Test
src/game/           Konfiguration, Verschlüsselung, Spielstand
src/screens/        Kalender, Tag, Zugestellt, Notizbuch, Testmodus
src/puzzles/        Rätsel-Komponenten (Tresor, Album, Fußspuren, Unterschiede, Taschenlampe …)
src/components/     Schnee, Girlande, Audio, Medien, Briefmarken
```

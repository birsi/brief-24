// Liest content/texte.md (Export des Text-Dokuments) und content/loesungen.json
// und erzeugt src/generated/days.json. Fortsetzungen, Briefmarken und alles,
// was die Lösung verrät, werden mit der Antwort verschlüsselt (AES-GCM, Schlüssel
// per PBKDF2 aus der normalisierten Antwort). Zusätzlich gibt es pro Tag eine
// Verschlüsselung mit DEV_SECRET für den Testmodus.
import { readFileSync, writeFileSync, mkdirSync } from 'node:fs';
import { webcrypto as crypto } from 'node:crypto';
import { normalize } from './normalize.mjs';

const ITER = 120000;
const enc = new TextEncoder();
const b64 = (buf) => Buffer.from(buf).toString('base64');

const devSecret = process.env.DEV_SECRET || 'dev';
if (!process.env.DEV_SECRET) {
  console.warn('[content] DEV_SECRET ist nicht gesetzt – Testmodus-Schlüssel ist "dev". Für Vercel bitte setzen.');
}

const md = readFileSync(new URL('../content/texte.md', import.meta.url), 'utf8');
const loesungen = JSON.parse(readFileSync(new URL('../content/loesungen.json', import.meta.url), 'utf8')).tage;

// ---------- Markdown zerlegen ----------
const lines = md.split('\n');
const days = {};
let cur = null;
let section = null;
for (const raw of lines) {
  const line = raw.trimEnd();
  const dayMatch = line.match(/^## Tag (\d+) – (.+)$/);
  if (dayMatch) {
    cur = { nr: Number(dayMatch[1]), titel: dayMatch[2].trim(), meta: '', karte: [], erzaehlung: [], fortsetzung: [], hinweise: [], bildErzaehlung: '', bildAufloesung: '' };
    days[cur.nr] = cur;
    section = 'meta';
    continue;
  }
  if (/^## /.test(line)) { cur = null; section = null; continue; }
  if (!cur) continue;
  const h3 = line.match(/^### (.+)$/);
  if (h3) {
    const t = h3[1];
    if (t.startsWith('Karte – Story')) section = 'karte';
    else if (t.startsWith('App – Erzählung')) section = 'erzaehlung';
    else if (t.startsWith('App – Fortsetzung')) section = 'fortsetzung';
    else if (t.startsWith('Hinweise')) section = 'hinweise';
    else section = 'other';
    continue;
  }
  if (!line.trim()) continue;
  if (section === 'meta' && !cur.meta) { cur.meta = line.trim(); continue; }
  if (section === 'karte') { cur.karte.push(line.trim()); continue; }
  if (section === 'erzaehlung' || section === 'fortsetzung') {
    const bild = line.match(/^\*\*(Bild|Video) (Erzählung|Auflösung)\*\*(?: \([^)]*\))?:\s*(.+)$/);
    if (bild) {
      if (bild[2] === 'Erzählung') cur.bildErzaehlung = bild[3];
      else cur.bildAufloesung = bild[3];
      continue;
    }
    // Nur reine Erzählabsätze übernehmen: keine Labels, Listen, Zitate.
    if (line.includes('**') || /^[-*>]\s|^\d+\.\s|^\|/.test(line.trim())) {
      if (section === 'erzaehlung') cur._stopErz = true; // nach dem ersten Label endet die Erzählung
      continue;
    }
    if (section === 'erzaehlung' && cur._stopErz) continue;
    cur[section].push(line.trim());
    continue;
  }
  if (section === 'hinweise') {
    const m = line.match(/^\d+\.\s+(.+)$/);
    if (m) cur.hinweise.push(m[1].trim());
  }
}

// ---------- Verschlüsselung ----------
async function deriveKey(secret, salt) {
  const base = await crypto.subtle.importKey('raw', enc.encode(secret), 'PBKDF2', false, ['deriveKey']);
  return crypto.subtle.deriveKey({ name: 'PBKDF2', salt, iterations: ITER, hash: 'SHA-256' }, base, { name: 'AES-GCM', length: 256 }, false, ['encrypt', 'decrypt']);
}
async function wrap(secret, rawKey) {
  const salt = crypto.getRandomValues(new Uint8Array(16));
  const iv = crypto.getRandomValues(new Uint8Array(12));
  const k = await deriveKey(secret, salt);
  const ct = await crypto.subtle.encrypt({ name: 'AES-GCM', iv }, k, rawKey);
  return { salt: b64(salt), iv: b64(iv), ct: b64(ct) };
}
async function sha(s) { return b64(await crypto.subtle.digest('SHA-256', enc.encode(s))); }

const out = { iterations: ITER, devCheck: null, days: [] };
for (let nr = 1; nr <= 24; nr++) {
  const d = days[nr];
  const l = loesungen[String(nr)];
  if (!d) throw new Error(`Tag ${nr} fehlt in texte.md`);
  if (!l) throw new Error(`Tag ${nr} fehlt in loesungen.json`);
  if (d.erzaehlung.length === 0) console.warn(`[content] Tag ${nr}: keine Erzählung gefunden`);
  if (d.fortsetzung.length === 0) console.warn(`[content] Tag ${nr}: keine Fortsetzung gefunden`);

  const payload = {
    fortsetzung: d.fortsetzung,
    loesung: l.antworten[0],
    briefmarke: l.briefmarke || null,
    platte: l.platte || null,
    epilog: l.epilog || null,
  };
  const rawKey = crypto.getRandomValues(new Uint8Array(32));
  const contentKey = await crypto.subtle.importKey('raw', rawKey, 'AES-GCM', false, ['encrypt']);
  const iv = crypto.getRandomValues(new Uint8Array(12));
  const ct = await crypto.subtle.encrypt({ name: 'AES-GCM', iv }, contentKey, enc.encode(JSON.stringify(payload)));

  const variants = [...new Set(l.antworten.map(normalize))];
  const wraps = [];
  for (const v of variants) wraps.push(await wrap(`tag${nr}:${v}`, rawKey));
  const devWrap = await wrap(`tag${nr}:dev:${devSecret}`, rawKey);

  const spezial = {};
  for (const [k, msg] of Object.entries(l.spezial || {})) spezial[await sha(`tag${nr}:${normalize(k)}`)] = msg;

  out.days.push({
    nr,
    titel: d.titel,
    meta: d.meta,
    karte: d.karte,
    erzaehlung: d.erzaehlung,
    hinweise: d.hinweise.slice(0, 2),
    // Hinweis 3 ist die Lösung: nur leicht verschleiert, damit sie nicht beim Durchsehen auffällt.
    hinweis3: d.hinweise[2] ? Buffer.from([...d.hinweise[2]].reverse().join(''), 'utf8').toString('base64') : null,
    video: !!l.video,
    sealed: { iv: b64(iv), ct: b64(ct), wraps, devWrap },
    spezial,
  });
}
out.devCheck = await wrap(`devcheck:${devSecret}`, enc.encode('ok'));

mkdirSync(new URL('../src/generated/', import.meta.url), { recursive: true });
writeFileSync(new URL('../src/generated/days.json', import.meta.url), JSON.stringify(out));

// Bild-Prompts als Liste für die Medienproduktion
const prompts = Object.values(days).map((d) => `Tag ${d.nr} – ${d.titel}\n  Erzählung: ${d.bildErzaehlung}\n  Auflösung: ${d.bildAufloesung}`).join('\n\n');
writeFileSync(new URL('../content/bild-prompts.txt', import.meta.url), prompts + '\n');
console.log(`[content] 24 Tage erzeugt (${out.days.reduce((s, d) => s + d.erzaehlung.length, 0)} Erzählabsätze).`);

// Prüft, dass jede Antwort aus content/loesungen.json ihren Tag entschlüsselt,
// falsche Antworten scheitern und der Testmodus-Schlüssel funktioniert.
import { readFileSync } from 'node:fs';
import { webcrypto as crypto } from 'node:crypto';
import { normalize } from './normalize.mjs';

const data = JSON.parse(readFileSync(new URL('../src/generated/days.json', import.meta.url), 'utf8'));
const loes = JSON.parse(readFileSync(new URL('../content/loesungen.json', import.meta.url), 'utf8')).tage;
const enc = new TextEncoder();
const dec = new TextDecoder();
const b = (s) => Uint8Array.from(Buffer.from(s, 'base64'));
const dev = process.env.DEV_SECRET || 'dev';

async function unwrap(secret, w) {
  try {
    const base = await crypto.subtle.importKey('raw', enc.encode(secret), 'PBKDF2', false, ['deriveKey']);
    const k = await crypto.subtle.deriveKey({ name: 'PBKDF2', salt: b(w.salt), iterations: data.iterations, hash: 'SHA-256' }, base, { name: 'AES-GCM', length: 256 }, false, ['decrypt']);
    return new Uint8Array(await crypto.subtle.decrypt({ name: 'AES-GCM', iv: b(w.iv) }, k, b(w.ct)));
  } catch { return null; }
}
async function open(day, raw) {
  const k = await crypto.subtle.importKey('raw', raw, 'AES-GCM', false, ['decrypt']);
  return JSON.parse(dec.decode(await crypto.subtle.decrypt({ name: 'AES-GCM', iv: b(day.sealed.iv) }, k, b(day.sealed.ct))));
}
async function attempt(day, input) {
  const n = normalize(input);
  for (const w of day.sealed.wraps) {
    const raw = await unwrap(`tag${day.nr}:${n}`, w);
    if (raw) return open(day, raw);
  }
  return null;
}

let fail = 0;
for (const day of data.days) {
  const l = loes[day.nr];
  const variants = [...l.antworten, l.antworten[0].toLowerCase(), ` ${l.antworten[0]} `];
  for (const a of variants) {
    const p = await attempt(day, a);
    if (!p || p.fortsetzung.length === 0) { console.error(`✗ Tag ${day.nr}: "${a}" öffnet nicht`); fail++; }
  }
  if (await attempt(day, 'FALSCHEANTWORT')) { console.error(`✗ Tag ${day.nr}: falsche Antwort öffnet`); fail++; }
  const devRaw = await unwrap(`tag${day.nr}:dev:${dev}`, day.sealed.devWrap);
  if (!devRaw) { console.error(`✗ Tag ${day.nr}: Testmodus-Schlüssel passt nicht`); fail++; }
  for (const k of Object.keys(l.spezial || {})) {
    const h = Buffer.from(await crypto.subtle.digest('SHA-256', enc.encode(`tag${day.nr}:${normalize(k)}`))).toString('base64');
    if (!day.spezial[h]) { console.error(`✗ Tag ${day.nr}: Spezialantwort ${k} fehlt`); fail++; }
  }
  console.log(`✓ Tag ${String(day.nr).padStart(2)} ${day.titel.padEnd(28)} ${l.antworten.join(' / ')}`);
}
// Umlaut-Varianten
for (const [nr, a] of [[16, 'Schlüssel'], [17, 'zurück'], [24, 'Larissa Birsak']]) {
  if (!(await attempt(data.days[nr - 1], a))) { console.error(`✗ Tag ${nr}: "${a}" öffnet nicht`); fail++; }
}
if (fail) { console.error(`\n${fail} Fehler`); process.exit(1); }
console.log('\nAlle 24 Tage öffnen mit ihren Antworten.');

// Erzeugt QR-Codes für alle 24 Karten: npm run qr -- https://deine-domain.vercel.app
import QRCode from 'qrcode';
import { mkdirSync, writeFileSync } from 'node:fs';

const base = (process.argv[2] || '').replace(/\/$/, '');
if (!/^https?:\/\//.test(base)) {
  console.error('Bitte die Adresse der App angeben, z. B.: npm run qr -- https://brief-24.vercel.app');
  process.exit(1);
}
mkdirSync('qr', { recursive: true });
const opts = { margin: 1, color: { dark: '#8A6A2FFF', light: '#00000000' }, errorCorrectionLevel: 'M' };
for (let nr = 1; nr <= 24; nr++) {
  const url = `${base}/tag/${nr}`;
  const name = `qr/tag-${String(nr).padStart(2, '0')}`;
  writeFileSync(`${name}.svg`, await QRCode.toString(url, { ...opts, type: 'svg' }));
  await QRCode.toFile(`${name}.png`, url, { ...opts, width: 1200 });
  console.log(`${name}  →  ${url}`);
}
console.log('\nFertig: Ordner qr/ (SVG für Canva, PNG mit transparentem Hintergrund, Gold #8A6A2F).');

export type Wrap = { salt: string; iv: string; ct: string };

export type Briefmarke = {
  nr: number;
  buchstabe: string;
  motiv: string;
  stempel: string;
  jahr: number;
};

export type DayData = {
  nr: number;
  titel: string;
  meta: string;
  karte: string[];
  erzaehlung: string[];
  hinweise: string[];
  hinweis3: string | null;
  video: boolean;
  sealed: { iv: string; ct: string; wraps: Wrap[]; devWrap: Wrap };
  spezial: Record<string, string>;
};

export type GeneratedContent = {
  iterations: number;
  devCheck: Wrap;
  days: DayData[];
};

/** Was nach der richtigen Lösung entschlüsselt wird. */
export type Payload = {
  fortsetzung: string[];
  loesung: string;
  briefmarke: Briefmarke | null;
  platte: string | null;
  epilog: string[] | null;
};

export type NotizbuchEintrag = 'zimmer' | 'morse' | 'kurrent';

export type Widget =
  | { type: 'schluesselbrett'; haken: number[]; schilder: string[]; saetze: string[] }
  | { type: 'glocke'; schlaege: number; label: string }
  | { type: 'stimmen'; aussagen: { name: string; text: string }[] }
  | { type: 'tresor'; raeder: number }
  | { type: 'album'; fotos: string[]; treffer: number; rueckseite: string }
  | { type: 'fussspuren' }
  | { type: 'unterschiede' }
  | { type: 'bestellbuch' }
  | { type: 'aussagen'; sprecher: string; saetze: string[]; richtig: number; frage: string }
  | { type: 'taschenlampe' }
  | { type: 'morse'; muster: string }
  | { type: 'szene' }
  | { type: 'schloss' }
  | { type: 'hinweis'; text: string };

export type DayConfig = {
  frage: string;
  placeholder?: string;
  widget?: Widget;
  /** Notizbuch-Einträge, die beim Öffnen des Tages freigeschaltet werden. */
  oeffnet?: NotizbuchEintrag[];
  /** Notizbuch-Einträge, die nach dem Lösen freigeschaltet werden. */
  loest?: NotizbuchEintrag[];
};

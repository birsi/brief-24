import type { DayConfig } from './types';

/**
 * Rätsel-Konfiguration pro Tag. Keine Lösungen hier – die stehen nur in
 * content/loesungen.json und werden beim Build zum Verschlüsseln benutzt.
 */
export const CONFIG: Record<number, DayConfig> = {
  1: { frage: 'Wohin führt dich der Brief?' },
  2: {
    frage: 'Welches Zimmer bekommt Larissa?',
    placeholder: 'Zimmernummer',
    widget: {
      type: 'schluesselbrett',
      haken: [7, 12, 19, 24, 31],
      schilder: ['Frau Lenz', 'Dr. Hartl', 'Herr Reiter', 'Baustelle'],
      saetze: [
        'Frau Lenz bewohnt seit 1971 dasselbe Zimmer. Seine Nummer ist eine Primzahl, und kleiner als jede andere am Brett.',
        'Die Baustelle hat eine gerade Nummer, aber nicht die größere der beiden.',
        'Herr Dr. Hartl wohnt in einer Primzahl, die größer ist als die von Herrn Reiter.',
        'Herr Reiter wohnt nicht in einem Zimmer, dessen Quersumme sechs ergibt.',
        'Ein Zimmer bleibt übrig. Es ist das Ihre.',
      ],
    },
    loest: ['zimmer'],
  },
  3: { frage: 'Wohin wollte Albin dich schicken?', widget: { type: 'glocke', schlaege: 7, label: 'Lobbyuhr anhören' } },
  4: { frage: 'Was hat Albin unsichtbar notiert?' },
  5: {
    frage: 'Wer hat gelogen?',
    placeholder: 'Name',
    widget: {
      type: 'stimmen',
      aussagen: [
        { name: 'Constanze Morgenstern', text: 'Ich war ab zehn Uhr abends in meinem Büro. Ich habe es erst am Morgen verlassen.' },
        { name: 'Dr. Felix Hartl', text: 'Um halb elf habe ich noch einen Cognac an der Bar getrunken. Danach war ich auf meinem Zimmer.' },
        { name: 'Jonas Reiter', text: 'Ich habe bis nach Mitternacht in der Bibliothek geschrieben.' },
        { name: 'Frau Elisabeth Lenz', text: 'Ich schlafe um neun. Immer.' },
        { name: 'Mira Novak', text: 'Um zehn hatte ich Dienstschluss. Ich bin sofort hinauf in mein Zimmer.' },
        { name: 'Bruno Kessler', text: 'Ich habe bis Mitternacht die Küche geputzt. Allein.' },
      ],
    },
  },
  6: { frage: 'Öffne Constanzes Tresor.', widget: { type: 'tresor', raeder: 3 } },
  7: { frage: 'Was wollte Mira verbergen?', oeffnet: ['morse'] },
  8: {
    frage: 'Wie nannte man Frau Lenz als Kind?',
    widget: {
      type: 'album',
      fotos: [
        'Eine Familie im Speisesaal, alle in Festkleidung',
        'Die Fassade des Morgenstern, Fahnen über dem Portal',
        'Zwei Pagen auf der Freitreppe, lachend',
        'Ein kleines Mädchen im Wollmantel im verschneiten Hof',
        'Ein Ball im großen Saal, unscharf vor Bewegung',
        'Der Christbaum in der Lobby, mit echten Kerzen',
      ],
      treffer: 3,
      rueckseite: 'Lisl, 3 Jahre, Weihnachten 1926, mit der Dame und ihrem Hund',
    },
  },
  9: { frage: 'Wo wurde die Kugel gemacht?', oeffnet: ['kurrent'] },
  10: { frage: 'Wessen Zimmer ist das?', placeholder: 'Name', widget: { type: 'fussspuren' } },
  11: { frage: 'Was hat Hartl anfertigen lassen?' },
  12: { frage: 'Was ist Hartls Kugel?', widget: { type: 'unterschiede' } },
  13: { frage: 'Was verraten die Stempel?' },
  14: { frage: 'Welche Bestellnummer suchst du?', placeholder: 'Nummer', widget: { type: 'bestellbuch' } },
  15: { frage: 'Wo beginnt der Weg ins Archiv?' },
  16: {
    frage: 'Was steckt im Sockel?',
    widget: {
      type: 'aussagen',
      sprecher: 'Jonas',
      frage: 'Welcher Satz verrät, dass Jonas mehr weiß, als er wissen dürfte?',
      saetze: [
        'Das Morgenstern wurde achtzehnhundertdreiundsiebzig eröffnet, zur Weltausstellung. Steht in jedem Reiseführer.',
        'Hartl ist ein Aufschneider. Murano, Dornbach, der verkauft seiner eigenen Großmutter eine Replik.',
        'Frau Lenz erzählt jedem von der Dame mit dem Hund. Die arme Frau lebt in ihrer eigenen Zeit.',
        'Wer die Kugel hat, hat noch lange nicht, was in ihrem Sockel steckt.',
      ],
      richtig: 3,
    },
  },
  17: { frage: 'Was steht auf dem Stein?' },
  18: { frage: 'Wohin schickt dich Albin?', widget: { type: 'taschenlampe' } },
  19: { frage: 'Welche Aufnahme liegt im Grammophon?', placeholder: 'Nummer', widget: { type: 'hinweis', text: 'Bring Albins Grammophon zum Sprechen.' } },
  20: { frage: 'Wer hat die Seite herausgerissen?', placeholder: 'Name' },
  21: { frage: 'Welches Wort öffnet den Zylinder?' },
  22: { frage: 'Was sagt das Uhrwerk?', widget: { type: 'morse', muster: '...- .. . .-.' } },
  23: { frage: 'Wer hat dich hergeführt?', placeholder: 'Name', widget: { type: 'szene' } },
  24: { frage: 'Wessen Bibliothek?', placeholder: 'Name', widget: { type: 'schloss' } },
};

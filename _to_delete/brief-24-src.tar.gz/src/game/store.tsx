import { createContext, useCallback, useContext, useEffect, useMemo, useState, type ReactNode } from 'react';
import { CONFIG } from './config';
import { checkDevSecret, devSolve, openPayload, tryAnswer, type TryResult } from './crypto';
import type { NotizbuchEintrag, Payload } from './types';

export const GAME_YEAR = 2026;
/** Minuten bis Hinweis 1, 2 und 3 nach dem ersten Öffnen eines Tages verfügbar sind. */
export const HINT_MINUTES = [3, 8, 15];

const KEY = 'brief24:v1';
const DEV_KEY = 'brief24:dev';

type Progress = {
  solved: Record<number, string>;
  opened: Record<number, number>;
  hints: Record<number, number>;
};

type DevState = { secret: string | null; ignoreDate: boolean; simDate: string | null; showSolutions: boolean };

function load<T>(key: string, fallback: T): T {
  try {
    const raw = localStorage.getItem(key);
    return raw ? { ...fallback, ...JSON.parse(raw) } : fallback;
  } catch {
    return fallback;
  }
}
function save(key: string, v: unknown) {
  try {
    localStorage.setItem(key, JSON.stringify(v));
  } catch {
    /* Speicher nicht verfügbar */
  }
}

/** Heutiges Datum in Wien als YYYY-MM-DD. */
export function viennaToday(): string {
  return new Intl.DateTimeFormat('en-CA', { timeZone: 'Europe/Vienna', year: 'numeric', month: '2-digit', day: '2-digit' }).format(new Date());
}
export function dayDate(nr: number) {
  return `${GAME_YEAR}-12-${String(nr).padStart(2, '0')}`;
}

type Ctx = {
  progress: Progress;
  payloads: Record<number, Payload>;
  dev: DevState;
  today: string;
  isDev: boolean;
  isUnlocked: (nr: number) => boolean;
  isSolved: (nr: number) => boolean;
  submit: (nr: number, input: string) => Promise<TryResult>;
  markOpened: (nr: number) => void;
  revealHint: (nr: number) => void;
  notizbuch: Set<NotizbuchEintrag>;
  // Testmodus
  enableDev: (secret: string) => Promise<boolean>;
  setDev: (patch: Partial<DevState>) => void;
  devSolveDay: (nr: number) => Promise<boolean>;
  resetDay: (nr: number) => void;
  resetAll: () => void;
};

const GameCtx = createContext<Ctx | null>(null);

export function GameProvider({ children }: { children: ReactNode }) {
  const [progress, setProgress] = useState<Progress>(() => load(KEY, { solved: {}, opened: {}, hints: {} }));
  const [dev, setDevState] = useState<DevState>(() => load(DEV_KEY, { secret: null, ignoreDate: false, simDate: null, showSolutions: false }));
  const [payloads, setPayloads] = useState<Record<number, Payload>>({});
  const [now, setNow] = useState(viennaToday());

  useEffect(() => save(KEY, progress), [progress]);
  useEffect(() => save(DEV_KEY, dev), [dev]);

  // Datum regelmäßig prüfen, damit um Mitternacht der nächste Tag aufgeht.
  useEffect(() => {
    const t = setInterval(() => setNow(viennaToday()), 30_000);
    return () => clearInterval(t);
  }, []);

  // Inhalte bereits gelöster Tage entschlüsseln.
  useEffect(() => {
    let alive = true;
    (async () => {
      const next: Record<number, Payload> = {};
      for (const [nr, key] of Object.entries(progress.solved)) {
        const p = await openPayload(Number(nr), key);
        if (p) next[Number(nr)] = p;
      }
      if (alive) setPayloads(next);
    })();
    return () => {
      alive = false;
    };
  }, [progress.solved]);

  // ?dev=geheimnis in der URL schaltet den Testmodus frei.
  useEffect(() => {
    const p = new URLSearchParams(window.location.search).get('dev');
    if (!p) return;
    checkDevSecret(p).then((ok) => {
      if (ok) setDevState((d) => ({ ...d, secret: p }));
      const url = new URL(window.location.href);
      url.searchParams.delete('dev');
      window.history.replaceState(null, '', url.toString());
    });
  }, []);

  const isDev = !!dev.secret;
  const today = isDev && dev.simDate ? dev.simDate : now;

  const isUnlocked = useCallback(
    (nr: number) => (isDev && dev.ignoreDate) || today >= dayDate(nr),
    [isDev, dev.ignoreDate, today],
  );
  const isSolved = useCallback((nr: number) => !!progress.solved[nr], [progress.solved]);

  const submit = useCallback(async (nr: number, input: string) => {
    const res = await tryAnswer(nr, input);
    if (res.ok) {
      setPayloads((p) => ({ ...p, [nr]: res.payload }));
      setProgress((p) => ({ ...p, solved: { ...p.solved, [nr]: res.key } }));
    }
    return res;
  }, []);

  const markOpened = useCallback((nr: number) => {
    setProgress((p) => (p.opened[nr] ? p : { ...p, opened: { ...p.opened, [nr]: Date.now() } }));
  }, []);

  const revealHint = useCallback((nr: number) => {
    setProgress((p) => ({ ...p, hints: { ...p.hints, [nr]: Math.min(3, (p.hints[nr] ?? 0) + 1) } }));
  }, []);

  const notizbuch = useMemo(() => {
    const s = new Set<NotizbuchEintrag>();
    for (let nr = 1; nr <= 24; nr++) {
      const c = CONFIG[nr];
      if (progress.opened[nr]) c.oeffnet?.forEach((e) => s.add(e));
      if (progress.solved[nr]) {
        c.oeffnet?.forEach((e) => s.add(e));
        c.loest?.forEach((e) => s.add(e));
      }
    }
    return s;
  }, [progress.opened, progress.solved]);

  const enableDev = useCallback(async (secret: string) => {
    const ok = await checkDevSecret(secret);
    if (ok) setDevState((d) => ({ ...d, secret }));
    return ok;
  }, []);
  const setDev = useCallback((patch: Partial<DevState>) => setDevState((d) => ({ ...d, ...patch })), []);

  const devSolveDay = useCallback(
    async (nr: number) => {
      if (!dev.secret) return false;
      const res = await devSolve(nr, dev.secret);
      if (res.ok) {
        setPayloads((p) => ({ ...p, [nr]: res.payload }));
        setProgress((p) => ({ ...p, solved: { ...p.solved, [nr]: res.key }, opened: { ...p.opened, [nr]: p.opened[nr] ?? Date.now() } }));
      }
      return res.ok;
    },
    [dev.secret],
  );

  const resetDay = useCallback((nr: number) => {
    setProgress((p) => {
      const solved = { ...p.solved };
      const opened = { ...p.opened };
      const hints = { ...p.hints };
      delete solved[nr];
      delete opened[nr];
      delete hints[nr];
      return { solved, opened, hints };
    });
  }, []);
  const resetAll = useCallback(() => setProgress({ solved: {}, opened: {}, hints: {} }), []);

  const value: Ctx = {
    progress,
    payloads,
    dev,
    today,
    isDev,
    isUnlocked,
    isSolved,
    submit,
    markOpened,
    revealHint,
    notizbuch,
    enableDev,
    setDev,
    devSolveDay,
    resetDay,
    resetAll,
  };
  return <GameCtx.Provider value={value}>{children}</GameCtx.Provider>;
}

export function useGame() {
  const c = useContext(GameCtx);
  if (!c) throw new Error('useGame außerhalb von GameProvider');
  return c;
}

import { Link, Navigate, useParams } from 'react-router-dom';
import { AudioPlayer, Marke, Media, mediaPath, StoryText, TopBar } from '../components/ui';
import { Funken, Ornament, Snow } from '../components/Deko';
import { DAYS } from '../game/crypto';
import { useGame } from '../game/store';
import { useEffect } from 'react';

const ROEMISCH = ['', 'I', 'II', 'III', 'IV', 'V', 'VI', 'VII', 'VIII', 'IX', 'X', 'XI', 'XII'];

export default function Zugestellt() {
  const nr = Number(useParams().nr);
  const day = DAYS[nr - 1];
  const g = useGame();
  const payload = g.payloads[nr];

  useEffect(() => window.scrollTo(0, 0), [nr]);

  if (!day || !g.isSolved(nr)) return <Navigate to={`/tag/${nr}`} replace />;
  if (!payload) return <div className="app" style={{ padding: 40 }}><p className="small">Brief wird geöffnet …</p></div>;

  return (
    <div className="app">
      <Snow count={40} opacity={0.8} />
      <TopBar title={`Tag ${nr} · Gelöst`} />

      <div style={{ position: 'relative', display: 'flex', justifyContent: 'center', padding: '6px 0 20px' }}>
        <Funken />
        <div className="stamp-in" style={{ width: 132, height: 132, borderRadius: '50%', border: '2px solid var(--gold)', display: 'flex', alignItems: 'center', justifyContent: 'center', transform: 'rotate(-8deg)' }}>
          <div style={{ width: 116, height: 116, borderRadius: '50%', border: '1px solid var(--gold)', display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: 2, color: 'var(--gold)' }}>
            <span className="label" style={{ letterSpacing: '0.2em' }}>Zugestellt</span>
            <span style={{ fontFamily: 'var(--serif-display)', fontWeight: 600, fontSize: 25, lineHeight: 1.1 }}>ZEITPOST</span>
            <span style={{ fontFamily: 'var(--sans)', fontSize: 12, letterSpacing: '0.1em' }}>{nr}. {ROEMISCH[12]}. 2026</span>
          </div>
        </div>
      </div>

      <Media nr={nr} kind="aufloesung" video={day.video} label={`${day.video ? 'Video' : 'Bild'} Auflösung · Tag ${nr}`} />

      <div style={{ padding: '22px 24px 0', display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 8 }}>
        <h2 style={{ fontSize: 28, textAlign: 'center' }}>{day.titel}</h2>
        <Ornament />
      </div>

      <AudioPlayer key={`fs-${nr}`} src={mediaPath(nr, 'fortsetzung.mp3')} text={payload.fortsetzung} label="Fortsetzung" />

      <div style={{ padding: '20px 24px 0' }}>
        <StoryText paragraphs={payload.fortsetzung} />
      </div>

      {payload.platte ? (
        <div style={{ marginTop: 22 }}>
          <div className="label" style={{ textAlign: 'center' }}>Die Platte von 1926</div>
          <AudioPlayer key={`pl-${nr}`} src={mediaPath(nr, 'platte.mp3')} text={[payload.platte]} label="Aufnahme 1224" />
        </div>
      ) : null}

      {payload.briefmarke ? (
        <div className="float" style={{ margin: '28px 16px 0', padding: 18, border: '1px solid var(--gold)', background: 'var(--navy-2)', boxShadow: '0 10px 30px rgba(0,0,0,.35)', display: 'flex', alignItems: 'center', gap: 18 }}>
          <Marke m={payload.briefmarke} />
          <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
            <div className="label" style={{ letterSpacing: '0.2em' }}>Briefmarke {payload.briefmarke.nr} von 6</div>
            <div style={{ fontFamily: 'var(--serif-display)', fontWeight: 600, fontSize: 22, lineHeight: 1.2 }}>{payload.briefmarke.motiv}</div>
            <div style={{ fontSize: 16, lineHeight: 1.45, color: '#D5DAE2' }}>
              Stempel {payload.briefmarke.stempel}
              <br />
              Rückseite: <strong style={{ color: 'var(--ink)' }}>{payload.briefmarke.buchstabe}</strong>
            </div>
            <div className="small">Ins Notizbuch gelegt</div>
          </div>
        </div>
      ) : null}

      {payload.epilog ? (
        <div className="card-gold kerze" style={{ margin: '32px 16px 0', textAlign: 'center', display: 'flex', flexDirection: 'column', gap: 10 }}>
          {payload.epilog.map((l, i) => (
            <p key={i} style={{ margin: 0, fontStyle: 'italic', fontSize: 20, lineHeight: 1.5 }}>{l}</p>
          ))}
        </div>
      ) : null}

      <div style={{ margin: '28px 16px 48px', display: 'flex', flexDirection: 'column', gap: 10 }}>
        <Link to="/" className="btn btn-outline-gold">Zum Kalender</Link>
        {nr < 24 ? (
          g.isUnlocked(nr + 1) ? (
            <Link to={`/tag/${nr + 1}`} className="btn">Weiter zu Tag {nr + 1}</Link>
          ) : (
            <div className="small" style={{ textAlign: 'center' }}>Tag {nr + 1} öffnet sich am {nr + 1}. Dezember um 0:00 Uhr</div>
          )
        ) : (
          <div className="small" style={{ textAlign: 'center' }}>Frohe Weihnachten, Larissa.</div>
        )}
      </div>
    </div>
  );
}

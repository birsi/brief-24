import { useState } from 'react';
import { BottomNav, Marke } from '../components/ui';
import { Snow, SnowBank } from '../components/Deko';
import { useGame } from '../game/store';
import type { Briefmarke } from '../game/types';

export const MORSE: Record<string, string> = {
  A: '.-', B: '-...', C: '-.-.', D: '-..', E: '.', F: '..-.', G: '--.', H: '....', I: '..', J: '.---', K: '-.-', L: '.-..', M: '--',
  N: '-.', O: '---', P: '.--.', Q: '--.-', R: '.-.', S: '...', T: '-', U: '..-', V: '...-', W: '.--', X: '-..-', Y: '-.--', Z: '--..',
};

const MARKEN_TAGE = [3, 6, 9, 12, 15, 18];

type Tab = 'marken' | 'morse' | 'kurrent' | 'funde';

export default function Notizbuch() {
  const { payloads, notizbuch } = useGame();
  const [tab, setTab] = useState<Tab>('marken');
  const marken = MARKEN_TAGE.map((t) => ({ tag: t, m: payloads[t]?.briefmarke as Briefmarke | undefined }));
  const count = marken.filter((x) => x.m).length;

  const tabs: { id: Tab; label: string; on: boolean }[] = [
    { id: 'marken', label: 'Briefmarken', on: true },
    { id: 'morse', label: 'Morse', on: notizbuch.has('morse') },
    { id: 'kurrent', label: 'Kurrent', on: notizbuch.has('kurrent') },
    { id: 'funde', label: 'Funde', on: notizbuch.has('zimmer') },
  ];

  return (
    <div className="app">
      <Snow count={28} opacity={0.7} />
      <header style={{ padding: '56px 20px 14px', display: 'flex', flexDirection: 'column', gap: 4 }}>
        <div className="label">Larissas</div>
        <h1 style={{ fontSize: 34 }}>Notizbuch</h1>
      </header>

      <div role="tablist" aria-label="Notizbuch-Bereiche" style={{ padding: '0 20px 18px', display: 'flex', flexWrap: 'wrap', gap: 8 }}>
        {tabs.filter((t) => t.on).map((t) => (
          <button
            key={t.id}
            role="tab"
            aria-selected={tab === t.id}
            onClick={() => setTab(t.id)}
            style={{ minHeight: 44, padding: '0 14px', fontFamily: 'var(--sans)', fontSize: 12, letterSpacing: '0.14em', textTransform: 'uppercase', background: tab === t.id ? 'var(--gold)' : 'transparent', color: tab === t.id ? 'var(--navy)' : '#D5DAE2', border: `1px solid ${tab === t.id ? 'var(--gold)' : 'var(--line-2)'}` }}
          >
            {t.label}
          </button>
        ))}
      </div>

      <main style={{ flexGrow: 1, padding: '0 20px 24px', position: 'relative' }}>
        {tab === 'marken' ? (
          <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline' }}>
              <h2 style={{ fontSize: 22 }}>Briefmarken</h2>
              <span className="small">{count} von 6</span>
            </div>
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, minmax(0, 1fr))', gap: 12 }}>
              {marken.map(({ tag, m }) =>
                m ? (
                  <Marke key={tag} m={m} small />
                ) : (
                  <div key={tag} style={{ height: 150, margin: 4, border: '1px dashed var(--line-2)', display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: 6, color: 'var(--muted-2)', fontFamily: 'var(--sans)', fontSize: 12, letterSpacing: '0.1em' }}>
                    <span style={{ fontFamily: 'var(--serif-display)', fontSize: 26 }}>?</span>
                    <span>TAG {tag}</span>
                  </div>
                ),
              )}
            </div>
            <p style={{ margin: '4px 0 0', fontSize: 16, lineHeight: 1.5, color: '#D5DAE2' }}>Jede Marke trägt einen Buchstaben und einen Poststempel.</p>
          </div>
        ) : null}

        {tab === 'morse' ? (
          <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
            <h2 style={{ fontSize: 22 }}>Tafel aus dem Telegrafenzimmer</h2>
            <p style={{ margin: 0, fontSize: 16, color: '#D5DAE2' }}>Punkt = kurz, Strich = lang.</p>
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, minmax(0, 1fr))', gap: '6px 12px' }}>
              {Object.entries(MORSE).map(([l, c]) => (
                <div key={l} style={{ display: 'flex', gap: 10, alignItems: 'baseline', borderBottom: '1px solid #22344E', padding: '6px 0' }}>
                  <span style={{ fontFamily: 'var(--serif-display)', fontWeight: 600, fontSize: 20, color: 'var(--gold)', width: 18 }}>{l}</span>
                  <span style={{ fontFamily: 'var(--mono)', fontSize: 17, letterSpacing: '0.2em' }}>{c.replace(/\./g, '·').replace(/-/g, '–')}</span>
                </div>
              ))}
            </div>
          </div>
        ) : null}

        {tab === 'kurrent' ? (
          <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
            <h2 style={{ fontSize: 22 }}>Kurrentschrift</h2>
            <p style={{ margin: 0, fontSize: 16, color: '#D5DAE2' }}>Die alte deutsche Schreibschrift, wie in den Briefen der Urgroßeltern.</p>
            <img src="/media/kurrent-tabelle.png" alt="Tabelle der Kurrentschrift von A bis Z" style={{ width: '100%', background: 'var(--paper)' }} onError={(e) => { (e.currentTarget.style.display = 'none'); }} />
          </div>
        ) : null}

        {tab === 'funde' ? (
          <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
            <h2 style={{ fontSize: 22 }}>Zimmerbelegung</h2>
            <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: 17 }}>
              <tbody>
                {[
                  ['7', 'Frau Elisabeth Lenz'],
                  ['12', 'Baustelle'],
                  ['19', 'Jonas Reiter'],
                  ['24', 'Larissa'],
                  ['31', 'Dr. Felix Hartl'],
                ].map(([n, w]) => (
                  <tr key={n}>
                    <td style={{ padding: '9px 0', borderBottom: '1px solid #22344E', fontFamily: 'var(--serif-display)', fontWeight: 600, fontSize: 21, color: 'var(--gold)', width: 64 }}>{n}</td>
                    <td style={{ padding: '9px 0', borderBottom: '1px solid #22344E' }}>{w}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        ) : null}
      </main>

      <SnowBank />
      <BottomNav />
    </div>
  );
}

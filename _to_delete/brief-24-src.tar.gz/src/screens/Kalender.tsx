import { useNavigate } from 'react-router-dom';
import { BottomNav } from '../components/ui';
import { Garland, MorgensternIcon, Snow, SnowBank } from '../components/Deko';
import { dayDate, GAME_YEAR, useGame } from '../game/store';
import { DAYS } from '../game/crypto';

export default function Kalender() {
  const { isUnlocked, isSolved, payloads, today, isDev } = useGame();
  const nav = useNavigate();
  const marken = Object.values(payloads).filter((p) => p.briefmarke).length;
  const heiligabend = new Date(`${GAME_YEAR}-12-24T00:00:00`);
  const heute = new Date(`${today}T00:00:00`);
  const noch = Math.round((heiligabend.getTime() - heute.getTime()) / 86400000);
  const vorStart = today < dayDate(1) && !isUnlocked(1);

  return (
    <div className="app">
      <Snow count={45} />
      <Garland />
      <div aria-hidden="true" style={{ position: 'absolute', left: '50%', top: 20, width: 420, height: 300, marginLeft: -210, background: 'radial-gradient(closest-side, rgba(212,178,106,0.20), rgba(212,178,106,0))', pointerEvents: 'none' }} />

      <header style={{ padding: '62px 20px 14px', display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 6, position: 'relative' }}>
        <MorgensternIcon className="star" />
        <div className="label" style={{ letterSpacing: '0.24em', textAlign: 'center' }}>Zeitpost · Grand Hotel Morgenstern</div>
        <h1 style={{ fontSize: 30, textAlign: 'center' }}>Der Brief vom 24. Dezember</h1>
        <div className="small" style={{ display: 'flex', gap: 18, marginTop: 4, flexWrap: 'wrap', justifyContent: 'center' }}>
          {vorStart ? <span>Die erste Zustellung kommt am 1. Dezember</span> : noch > 0 ? <span>Noch {noch} {noch === 1 ? 'Tag' : 'Tage'} bis Heiligabend</span> : <span>Heiligabend</span>}
          <span>{marken} von 6 Briefmarken</span>
          {isDev ? <span style={{ color: '#E8A15A' }}>Testmodus</span> : null}
        </div>
      </header>

      <main style={{ flexGrow: 1, padding: '6px 20px 0', display: 'grid', gridTemplateColumns: 'repeat(4, minmax(0, 1fr))', gap: 10, alignContent: 'start', position: 'relative' }}>
        {DAYS.map((d) => {
          const solved = isSolved(d.nr);
          const open = isUnlocked(d.nr);
          const isToday = open && !solved && (today === dayDate(d.nr) || !DAYS.some((x) => x.nr < d.nr && isUnlocked(x.nr) && !isSolved(x.nr)));
          if (solved) {
            return (
              <button key={d.nr} onClick={() => nav(`/tag/${d.nr}`)} aria-label={`Tag ${d.nr}, ${d.titel}, gelöst`} style={{ height: 76, border: '1px solid var(--gold)', background: 'var(--navy-3)', display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: 4, padding: 0 }}>
                <span style={{ fontFamily: 'var(--serif-display)', fontWeight: 600, fontSize: 24, lineHeight: 1 }}>{d.nr}</span>
                <span aria-hidden="true" style={{ width: 22, height: 22, borderRadius: '50%', background: 'var(--rot)', boxShadow: '0 1px 0 rgba(0,0,0,.35), inset 0 0 0 2px rgba(0,0,0,.18)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                  <svg width="11" height="11" viewBox="0 0 12 12"><path d="M6 0 L7 5 L12 6 L7 7 L6 12 L5 7 L0 6 L5 5 Z" fill="var(--gold)" /></svg>
                </span>
              </button>
            );
          }
          if (open) {
            return (
              <button key={d.nr} onClick={() => nav(`/tag/${d.nr}`)} className={isToday ? 'today' : undefined} aria-label={`Tag ${d.nr}, ${d.titel}, offen`} style={{ height: 76, border: '2px solid var(--gold)', background: 'var(--navy-2)', color: 'var(--gold)', display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: 3, padding: 0, position: 'relative' }}>
                {isToday ? (
                  <svg aria-hidden="true" width="34" height="14" viewBox="0 0 34 14" style={{ position: 'absolute', top: -1, left: '50%', marginLeft: -17 }}>
                    <path d="M17 7 C11 -1 3 1 6 7 C3 13 11 15 17 7 Z" fill="var(--rot)" />
                    <path d="M17 7 C23 -1 31 1 28 7 C31 13 23 15 17 7 Z" fill="var(--rot)" />
                    <circle cx="17" cy="7" r="2.6" fill="var(--gold)" />
                  </svg>
                ) : null}
                <span style={{ fontFamily: 'var(--serif-display)', fontWeight: 600, fontSize: 28, lineHeight: 1, marginTop: isToday ? 6 : 0 }}>{d.nr}</span>
                <span style={{ fontFamily: 'var(--sans)', fontSize: 12, letterSpacing: '0.16em' }}>{isToday ? 'HEUTE' : 'OFFEN'}</span>
              </button>
            );
          }
          return (
            <button key={d.nr} disabled aria-label={`Tag ${d.nr}, noch verschlossen`} style={{ height: 76, border: '1px solid var(--line)', background: 'rgba(14,26,43,0.6)', color: 'var(--muted-2)', display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: 4, padding: 0, cursor: 'default' }}>
              <span style={{ fontFamily: 'var(--serif-display)', fontWeight: 500, fontSize: 24, lineHeight: 1 }}>{d.nr}</span>
              <svg width="12" height="14" viewBox="0 0 12 14" aria-hidden="true"><rect x="1" y="6" width="10" height="7" rx="1" fill="none" stroke="currentColor" strokeWidth="1.2" /><path d="M3.5 6 V4 a2.5 2.5 0 0 1 5 0 V6" fill="none" stroke="currentColor" strokeWidth="1.2" /></svg>
            </button>
          );
        })}
      </main>

      <div style={{ height: 24 }} />
      <SnowBank />
      <BottomNav />
    </div>
  );
}

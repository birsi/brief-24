import { useEffect, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { DAYS, devSolve } from '../game/crypto';
import { dayDate, useGame } from '../game/store';

export default function Dev() {
  const g = useGame();
  const nav = useNavigate();
  const [secret, setSecret] = useState('');
  const [err, setErr] = useState(false);
  const [loesungen, setLoesungen] = useState<Record<number, string>>({});
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    if (!g.isDev || !g.dev.showSolutions || !g.dev.secret) return;
    let alive = true;
    (async () => {
      const out: Record<number, string> = {};
      for (const d of DAYS) {
        const r = await devSolve(d.nr, g.dev.secret!);
        if (r.ok) out[d.nr] = r.payload.loesung;
      }
      if (alive) setLoesungen(out);
    })();
    return () => {
      alive = false;
    };
  }, [g.isDev, g.dev.showSolutions, g.dev.secret]);

  const wrap: React.CSSProperties = { background: '#0B1522', fontFamily: 'var(--sans)' };

  if (!g.isDev) {
    return (
      <div className="app" style={{ ...wrap, padding: '60px 20px', gap: 16 }}>
        <h1 style={{ fontFamily: 'var(--sans)', fontSize: 22 }}>Testmodus</h1>
        <form
          onSubmit={async (e) => {
            e.preventDefault();
            const ok = await g.enableDev(secret);
            setErr(!ok);
          }}
          style={{ display: 'flex', flexDirection: 'column', gap: 12 }}
        >
          <label htmlFor="devsecret" className="small">Dev-Geheimnis</label>
          <input id="devsecret" className="input" type="password" value={secret} onChange={(e) => setSecret(e.target.value)} style={{ textTransform: 'none', letterSpacing: 0 }} />
          {err ? <p role="status" style={{ margin: 0, color: '#E8A15A' }}>Falsch.</p> : null}
          <button className="btn" type="submit">Freischalten</button>
        </form>
        <Link to="/" className="small">Zurück</Link>
      </div>
    );
  }

  const status = (nr: number) => (g.isSolved(nr) ? ['GELÖST', '#7CC79A'] : g.isUnlocked(nr) ? ['OFFEN', '#E8A15A'] : ['GESPERRT', '#8C97AA']);
  const smallBtn: React.CSSProperties = { minHeight: 44, padding: '0 10px', background: 'transparent', border: '1px solid var(--line-2)', fontFamily: 'var(--sans)', fontSize: 12, letterSpacing: '0.1em' };

  return (
    <div className="app" style={wrap}>
      <div style={{ padding: '52px 20px 14px', display: 'flex', alignItems: 'center', justifyContent: 'space-between', borderBottom: '1px solid #22344E' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
          <span style={{ background: '#E8A15A', color: '#0B1522', fontWeight: 600, fontSize: 12, letterSpacing: '0.16em', padding: '5px 8px' }}>DEV</span>
          <h1 style={{ fontFamily: 'var(--sans)', fontSize: 20 }}>Testmodus</h1>
        </div>
        <Link to="/" style={{ ...smallBtn, display: 'flex', alignItems: 'center', color: 'var(--ink)', textDecoration: 'none' }}>KALENDER</Link>
      </div>

      <div style={{ padding: '16px 20px', display: 'flex', flexDirection: 'column', gap: 12, borderBottom: '1px solid #22344E', fontSize: 15 }}>
        <label style={{ minHeight: 44, display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 12 }}>
          Datumssperre ignorieren
          <input type="checkbox" checked={g.dev.ignoreDate} onChange={(e) => g.setDev({ ignoreDate: e.target.checked })} style={{ width: 22, height: 22, accentColor: '#E8A15A' }} />
        </label>
        <label style={{ minHeight: 44, display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 12 }}>
          Lösungen anzeigen
          <input type="checkbox" checked={g.dev.showSolutions} onChange={(e) => g.setDev({ showSolutions: e.target.checked })} style={{ width: 22, height: 22, accentColor: '#E8A15A' }} />
        </label>
        <label style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 12 }}>
          Simuliertes Datum
          <span style={{ display: 'flex', gap: 6 }}>
            <input type="date" value={g.dev.simDate ?? ''} onChange={(e) => g.setDev({ simDate: e.target.value || null })} style={{ height: 44, background: '#0E1A2B', color: 'var(--ink)', border: '1px solid var(--line-2)', padding: '0 8px', fontFamily: 'var(--mono)', fontSize: 14 }} />
            {g.dev.simDate ? <button style={smallBtn} onClick={() => g.setDev({ simDate: null })}>ECHT</button> : null}
          </span>
        </label>
        <div className="small">Heute zählt als: {g.today}</div>
      </div>

      <div style={{ flexGrow: 1 }}>
        {DAYS.map((d) => {
          const [s, c] = status(d.nr);
          return (
            <div key={d.nr} style={{ padding: '12px 20px', borderBottom: '1px solid #1A2B44', display: 'flex', flexDirection: 'column', gap: 8 }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline', gap: 10 }}>
                <span style={{ fontWeight: 600, fontSize: 15 }}>Tag {d.nr} · {d.titel}</span>
                <span style={{ fontSize: 12, letterSpacing: '0.1em', color: c }}>{s}</span>
              </div>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', gap: 10 }}>
                <code style={{ fontFamily: 'var(--mono)', fontSize: 13, color: '#E8A15A' }}>{g.dev.showSolutions ? loesungen[d.nr] ?? '…' : dayDate(d.nr)}</code>
                <div style={{ display: 'flex', gap: 6 }}>
                  <button style={smallBtn} onClick={() => nav(`/tag/${d.nr}`)}>ÖFFNEN</button>
                  <button style={smallBtn} onClick={() => g.devSolveDay(d.nr)} disabled={g.isSolved(d.nr)}>LÖSEN</button>
                  <button style={smallBtn} aria-label={`Tag ${d.nr} zurücksetzen`} onClick={() => g.resetDay(d.nr)}>↺</button>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      <div style={{ padding: '14px 20px 28px', borderTop: '1px solid #22344E', display: 'grid', gridTemplateColumns: 'repeat(2, minmax(0, 1fr))', gap: 10 }}>
        <button
          style={{ ...smallBtn, minHeight: 48 }}
          disabled={busy}
          onClick={async () => {
            setBusy(true);
            for (const d of DAYS) if (!g.isSolved(d.nr)) await g.devSolveDay(d.nr);
            setBusy(false);
          }}
        >
          {busy ? '…' : 'ALLE LÖSEN'}
        </button>
        <button style={{ ...smallBtn, minHeight: 48, background: '#7A2E2E', borderColor: '#A84444', color: '#fff' }} onClick={() => confirm('Gesamten Fortschritt löschen?') && g.resetAll()}>
          ALLES ZURÜCKSETZEN
        </button>
        <button style={{ ...smallBtn, minHeight: 48, gridColumn: '1 / -1' }} onClick={() => g.setDev({ secret: null, ignoreDate: false, simDate: null, showSolutions: false })}>
          TESTMODUS BEENDEN
        </button>
      </div>
    </div>
  );
}

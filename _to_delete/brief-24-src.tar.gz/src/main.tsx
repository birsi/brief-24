import { StrictMode } from 'react';
import { createRoot } from 'react-dom/client';
import { BrowserRouter, Navigate, Route, Routes } from 'react-router-dom';
import { GameProvider } from './game/store';
import Kalender from './screens/Kalender';
import Tag from './screens/Tag';
import Zugestellt from './screens/Zugestellt';
import Notizbuch from './screens/Notizbuch';
import Dev from './screens/Dev';
import './styles.css';

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <BrowserRouter>
      <GameProvider>
        <Routes>
          <Route path="/" element={<Kalender />} />
          <Route path="/tag/:nr" element={<Tag />} />
          <Route path="/tag/:nr/zugestellt" element={<Zugestellt />} />
          <Route path="/notizbuch" element={<Notizbuch />} />
          <Route path="/dev" element={<Dev />} />
          <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>
      </GameProvider>
    </BrowserRouter>
  </StrictMode>,
);
